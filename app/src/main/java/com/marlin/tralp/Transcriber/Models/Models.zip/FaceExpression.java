package com.marlin.tralp.Model;

/**
 * Created by aneves on 5/19/2016.
 */
public class FaceExpression {

}
