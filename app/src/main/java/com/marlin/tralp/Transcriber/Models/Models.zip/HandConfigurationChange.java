package com.marlin.tralp.Transcriber.Models;

/**
 * Created by aneves on 5/17/2016.
 */
public class HandConfigurationChange extends Movement {

    public boolean MovementsThroughThatAddress(Sign candidate, int handCenterX, int handCenterY, double tolerance) {

        return true;
    }
}
