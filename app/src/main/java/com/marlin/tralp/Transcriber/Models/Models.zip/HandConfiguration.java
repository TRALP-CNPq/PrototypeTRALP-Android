package com.marlin.tralp.Model;

/**
 * Created by aneves on 5/19/2016.
 */
public class HandConfiguration {
    int cm;
    int codCm1;
    int codCm2;
    int polegar;
    int indicador;
    int meio;
    int anelarEMindinho;
    int dedosSeparados;
    int pontasDedosTocando;
}
